Magd Bayoumi (mb2363)

Known Issue: N/A

Did not discuss the assignment with anyone.

For the assignment, I realized later on that a helper function (drawLine) could have been implemented however I believed that there were enough differences that he code should just be written separetely in two places.